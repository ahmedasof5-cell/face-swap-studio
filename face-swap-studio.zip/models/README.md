The official `face_landmarker.task` model is downloaded by `bash scripts/fetch-assets.sh` or the GitHub Pages workflow. No placeholder model is provided.
