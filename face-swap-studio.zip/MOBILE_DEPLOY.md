# GitHub Pages first deployment from iPhone

The simplest iPhone upload route is to upload the single `face-swap-studio.zip` file to a new GitHub repository, then create the Pages workflow in the GitHub web editor. GitHub Actions unpacks the source archive and downloads the large official MediaPipe assets on GitHub's build runner.

Create `.github/workflows/pages.yml` and paste this complete workflow:

```yaml
name: Build and deploy Face Swap Studio to GitHub Pages
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out source
        uses: actions/checkout@v4
      - name: Unpack project archive (iPhone-friendly upload path)
        run: |
          if [ -f face-swap-studio.zip ] && [ ! -f index.html ]; then
            mkdir -p .source-unpack
            unzip -q face-swap-studio.zip -d .source-unpack
            cp -a .source-unpack/. .
            rm -rf .source-unpack
          fi
      - name: Set up Node (for npm pack only)
        uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Download local MediaPipe runtime and model
        run: bash scripts/fetch-assets.sh
      - name: Verify required assets
        run: |
          test -s vendor/mediapipe/vision_bundle.mjs
          test -s vendor/mediapipe/wasm/vision_wasm_internal.wasm
          test -s models/face_landmarker.task
      - name: Assemble clean Pages output
        run: |
          mkdir -p dist
          cp index.html manifest.webmanifest sw.js dist/
          cp -R css js vendor models dist/
          touch dist/.nojekyll
      - name: Configure Pages
        uses: actions/configure-pages@v5
      - name: Upload static site artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

Then:

1. Create a **Public** repository called `face-swap-studio` with the default branch `main`.
2. Upload `face-swap-studio.zip` into the repository root and commit it.
3. Create `.github/workflows/pages.yml`, paste the workflow above, and commit it.
4. Open **Actions** and wait for the build/deploy workflow to pass. The first build downloads the official MediaPipe package and model.
5. Open **Settings → Pages** if needed and select **GitHub Actions** as the source.
6. Open the deployment URL in Safari while online. Wait for the app shell and model to load; then reload once. The Service Worker caches runtime/model assets after successful downloads.
7. Test with Airplane Mode only after the first online page visit has completed.

The repo may retain `face-swap-studio.zip`; the deployed `dist/` folder does not include that archive.
