#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT
mkdir -p "$ROOT/vendor/mediapipe/wasm" "$ROOT/models"
command -v npm >/dev/null || { echo 'npm is required only for the asset bootstrap step.' >&2; exit 1; }
command -v curl >/dev/null || { echo 'curl is required only for the asset bootstrap step.' >&2; exit 1; }

echo 'Downloading the official MediaPipe Tasks Vision package…'
npm pack "@mediapipe/tasks-vision@0.10.14" --pack-destination "$TMP" >/dev/null
tar -xzf "$TMP"/mediapipe-tasks-vision-*.tgz -C "$TMP"
PKG="$TMP/package"
test -s "$PKG/vision_bundle.mjs" || { echo 'vision_bundle.mjs missing from the package.' >&2; exit 1; }
test -d "$PKG/wasm" || { echo 'MediaPipe wasm folder missing from the package.' >&2; exit 1; }
cp "$PKG/vision_bundle.mjs" "$ROOT/vendor/mediapipe/vision_bundle.mjs"
cp -a "$PKG/wasm/." "$ROOT/vendor/mediapipe/wasm/"

echo 'Downloading the official Face Landmarker model…'
curl --fail --location --retry 3 --output "$ROOT/models/face_landmarker.task" \
  'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task'

# Fail closed rather than leaving misleading empty or partial assets.
test -s "$ROOT/vendor/mediapipe/vision_bundle.mjs"
test -s "$ROOT/vendor/mediapipe/wasm/vision_wasm_internal.wasm"
test -s "$ROOT/models/face_landmarker.task"
[ "$(wc -c < "$ROOT/models/face_landmarker.task")" -gt 1000000 ] || { echo 'Model file looks incomplete.' >&2; exit 1; }
echo 'MediaPipe runtime, WASM files and model are present.'
