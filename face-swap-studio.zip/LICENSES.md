# Third-party runtime notices

The Face Swap Studio application source in this repository is provided for evaluation and modification. The local MediaPipe runtime is fetched from the official `@mediapipe/tasks-vision` npm package (version 0.10.14) during asset preparation and is distributed under the license included by that package. Review the upstream package license before redistributing a generated deployment artifact.

The Face Landmarker model is downloaded from Google's official MediaPipe model storage URL. Refer to the model documentation and license terms linked from the [MediaPipe Face Landmarker overview](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker).

The small Delaunay triangulator under `vendor/delaunator/` is an original, self-contained Bowyer-Watson implementation written for this project and does not copy the Delaunator package.
