import test from 'node:test';
import assert from 'node:assert/strict';
import { solveSimilarity, applySimilarity } from '../js/face-alignment.js';
import { OneEuroFilter, LandmarkStabilizer } from '../js/stabilizer.js';
import { triangulate } from '../vendor/delaunator/delaunator.js';

test('Procrustes similarity solves scale, rotation and translation', () => {
  const src = [{x:0,y:0},{x:2,y:0},{x:0,y:2},{x:2,y:2}];
  const dst = src.map(p => ({x:-p.y*2+7,y:p.x*2-3}));
  const t = solveSimilarity(src,dst,[0,1,2,3]);
  const q = applySimilarity({x:1,y:1},t);
  assert.ok(Math.abs(q.x-5)<1e-7); assert.ok(Math.abs(q.y-(-1))<1e-7);
  assert.ok(Math.abs(t.scale-2)<1e-7);
});

test('One Euro filter smooths a noisy signal and remains finite', () => {
  const f = new OneEuroFilter();
  const values = [0,1,0,1,0,1].map((v,i)=>f.filter(v,i/30));
  assert.equal(values.length,6); assert.ok(values.every(Number.isFinite));
  assert.ok(values[4] > 0 && values[4] < 1);
});

test('Landmark stabilizer keeps a short detection persistence window', () => {
  const s = new LandmarkStabilizer(); const p=[{x:.4,y:.5,z:0}];
  const first=s.process(p,1,.5); assert.equal(first.length,1);
  assert.ok(s.hold(5)); assert.ok(s.hold(5));
  s.hold(1);s.hold(1);s.hold(1);s.hold(1);s.hold(1);s.hold(1);
  assert.equal(s.hold(5),null);
});

test('Delaunay triangulator returns two triangles for a square', () => {
  const indices=triangulate([0,0, 1,0, 1,1, 0,1]);
  assert.equal(indices.length,6);
  assert.ok([...indices].every(i=>i>=0&&i<4));
});

test('468-point face mesh creates a dense clipped triangle set', async () => {
  const { buildFaceMesh, FACE_OVAL } = await import('../js/face-mesh.js');
  let seed=17;const random=()=>{seed=(seed*48271)%2147483647;return seed/2147483647;};
  const points=Array.from({length:468},()=>{const a=random()*Math.PI*2,r=Math.sqrt(random())*.44;return {x:.5+Math.cos(a)*r,y:.5+Math.sin(a)*r,z:0};});
  FACE_OVAL.forEach((id,i)=>{const a=-Math.PI/2+2*Math.PI*i/FACE_OVAL.length;points[id]={x:.5+Math.cos(a)*.47,y:.5+Math.sin(a)*.47,z:0};});
  const mesh=buildFaceMesh(points,640,480);
  assert.ok(mesh.count>500);assert.equal(mesh.sourcePoints.length,468);assert.equal(mesh.triangles.length,mesh.count*3);
});
