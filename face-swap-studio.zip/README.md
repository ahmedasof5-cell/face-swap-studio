# FACE SWAP STUDIO — Light Engine

A mobile-first, static browser application for locally processing a short video with a face texture extracted from a separately uploaded photograph. The UI is Arabic RTL. No user image/video is uploaded to a processing server.

> **Important technical boundary:** this is a 2-D landmark-driven mesh warp, not a modern generative face-reenactment model. It maps a source face texture across a triangulated target-face mesh, uses a similarity transform to retain source proportions, and adds bounded expression residuals from the target. It can look reasonable on a mostly frontal, single-face clip, but it is not reliable for strong profile turns, hands crossing the face, large occlusions, extreme lighting changes, or highly different expressions. The application does not claim photorealistic results for every clip.

## Features implemented

- Separate source-photo and target-video upload flow.
- MediaPipe Face Landmarker for image-mode source analysis and video-mode tracking; maximum two detections are requested so multiple faces can be rejected/flagged.
- GPU delegate initialization with CPU fallback.
- 468-point 2-D mesh, Delaunay triangulation, triangle clipping and feathered oval mask.
- Procrustes similarity alignment over stable eye/nose/temple anchors; bounded expression displacement controlled by Identity Lock.
- One Euro filtering with short tracking-loss persistence.
- Beard/jaw and forehead mask expansion controls.
- Luminance-based brightness/contrast adaptation, opacity and edge-feather controls.
- Live calibration inputs, tracking overlay, progress, preview and adaptive-resolution selection.
- Canvas capture + MediaRecorder export using only formats detected by the browser; original audio is added through Web Audio when supported.
- Service-worker caching of the app shell, WASM files and model after the first successful online load.
- GitHub Actions deployment workflow that retrieves official runtime assets into the deployment artifact. This makes an iPhone-only GitHub Pages deployment practical without a PC.

## Runtime dependency status

The application source and a local asset-bootstrap workflow are included. **The official MediaPipe package and model binaries are not embedded in this ZIP** because network downloads from npm and Google Storage failed in the build environment. A direct model-download attempt also failed; no binary assets were fabricated. No fake or empty runtime files are included.

The checked-in script `scripts/fetch-assets.sh` downloads and verifies the actual files when run in an environment with internet access:

- `@mediapipe/tasks-vision@0.10.14` `vision_bundle.mjs`
- the package's real `wasm/` runtime files
- the official `face_landmarker.task` model bundle

The GitHub Actions workflow performs this step automatically during deployment. The deployed site therefore receives actual local assets, and its Service Worker can cache them for offline use after the initial online visit.

## Use on iPhone (no PC required)

1. In Safari, open GitHub and sign in. Create a new **Public** repository named `face-swap-studio` (a private repository may require a plan that supports Pages).
2. In the repository, choose **Add file → Upload files** and upload the single `face-swap-studio.zip` archive from this delivery to the repository root. Commit it to `main`.
3. Create a new file using **Add file → Create new file**. Enter the path `.github/workflows/pages.yml`, then paste the complete workflow from `MOBILE_DEPLOY.md` in this project ZIP. Commit the workflow. It automatically unpacks the uploaded project archive, downloads the official MediaPipe assets, and deploys the site. The `.github/workflows/pages.yml` file inside the archive is also extracted, so later source updates can use the normal workflow.
4. Open the repository's **Actions** tab and confirm that **Build and deploy Face Swap Studio to GitHub Pages** completes successfully. The build checks that the local runtime and model exist before deployment.
5. Open **Settings → Pages**. The workflow normally configures Pages automatically; choose **GitHub Actions** as the build/deployment source if GitHub asks.
6. In **Actions**, wait until the Pages deployment is green. Open the `github-pages` deployment URL from the workflow or repository's Pages settings.
7. Open the site in Safari while online and let the first visit finish loading. The Service Worker caches the shell, model and WASM files. Reload once after the page has loaded. Then test offline by enabling Airplane Mode and re-opening the site.
8. Add the site to the Home Screen from Safari's Share menu for an app-like shortcut. iOS still runs it as a browser-based web app; it does not gain native background-processing privileges.

This archive-first route avoids uploading a directory tree or manually placing the large WASM/model files from iPhone. You only upload the ZIP, then create the one workflow file using the included `MOBILE_DEPLOY.md` text.

## Use with a computer / local server

1. Install Node.js 20+ and npm. Node is used only for bootstrap/tests; the deployed app has no Node server requirement.
2. From the project root run:

   ```bash
   bash scripts/fetch-assets.sh
   npm test
   npm run check
   ```

3. Serve the folder over `localhost` (ES modules and Service Workers do not work correctly from `file://`):

   ```bash
   python3 -m http.server 8080
   ```

4. Open `http://localhost:8080` in a modern browser. Select one clear source-face photograph and a target video of at most 30 seconds.
5. Press **تحليل الوجه وبدء المعاينة**. Adjust the ten controls, preview the full clip, then export.

## Technical behavior

### Face alignment

For source anchor coordinates \(s_i\) and target anchor coordinates \(t_i\), the engine centers both sets and solves a least-squares 2-D similarity transform:

\[
\begin{bmatrix}x'\\y'\end{bmatrix}=
\begin{bmatrix}a&-b\\b&a\end{bmatrix}
\begin{bmatrix}x\\y\end{bmatrix}+\begin{bmatrix}t_x\\t_y\end{bmatrix}
\]

where \(a\) and \(b\) are estimated from the dot/cross covariance of the anchor sets. For each landmark, the target residual relative to the rigidly aligned source point is clamped to 12% of the target eye-span before being mixed in with weight \(1-\text{IdentityLock}\). This is a 2-D approximation; it cannot reconstruct hidden facial surfaces during out-of-plane rotation.

### Masking and beard protection

The target face-oval polygon is expanded around its centroid. The lower half receives the Beard/Jaw expansion and the upper half receives Forehead expansion. The expanded polygon is rasterized with a configurable blur and used as a destination-in alpha mask for the face mesh. It extends the mask rather than explicitly segmenting beard hair; facial hair preservation therefore depends on the source photo and target alignment.

### Stabilization

Landmark x/y/z values pass through independent One Euro filters. The cutoff rises with the filtered derivative so fast motion receives less smoothing than near-stationary motion. Five frames of the last good coordinates may be held during short detector dropouts. Preview inference is throttled to roughly 9–10 detections/second to reduce mobile load; the exported recording attempts to process every decoded frame. Actual throughput depends on the device.

### Color matching

The renderer samples face-region luminance statistics at low resolution and derives bounded brightness and contrast corrections blended by Color Match Strength. This is a lightweight luminance approximation, not a per-channel color-grade or learned illumination transfer.

## Browser / iPhone compatibility notes

- Requires a secure context (HTTPS) or `localhost` for Service Worker and modern media APIs.
- The page detects supported `MediaRecorder` MIME types at runtime and prefers MP4 only when the browser reports it as supported; otherwise it selects a detected WebM type.
- Canvas recording and original-audio routing are capability-dependent. Audio is added with Web Audio only when `AudioContext`, `createMediaElementSource` and `createMediaStreamDestination` work together.
- Safari versions differ in MediaRecorder MIME support, Canvas `captureStream`, Web Share file support and available video decoders. The app does not promise Camera Roll saving; use the browser download/share sheet when available.
- MP4/MOV acceptance is not a guarantee that every internal codec is decodable. The browser's metadata/decode path is the final test.
- iPhone memory and thermal constraints are substantial. Keep clips short, use 480p for heavy source files, and close other Safari tabs. A 30-second 720p video can still exceed available memory on some devices.
- The hidden source video element stays in the DOM at a tiny, non-zero size and is not `display:none`, to avoid interfering with Safari's decoder.

## Validation report for this delivery

| Check | Result | Notes |
|---|---|---|
| Source files created | Passed | HTML, CSS, JS modules, manifest, Service Worker, workflow, scripts and tests are included. |
| JavaScript syntax check | Passed | `npm run check` completed with no syntax errors. |
| Core math/unit tests | Passed | `npm test`: 5/5 tests passed (Procrustes, One Euro filter, tracking persistence, Delaunay square and dense 468-point face mesh). |
| Relative module import paths | Passed | Static check found no missing authored local module imports. |
| HTML ID references | Passed | Static check found no duplicate IDs or missing IDs referenced by the app module. |
| Asset bootstrap shell syntax | Passed | `bash -n scripts/fetch-assets.sh` completed successfully. |
| MediaPipe runtime/model presence in ZIP | Not passed / not bundled | Network access was unavailable in the build container. Workflow/bootstrap retrieves verified official assets. |
| Local browser smoke test | Not completed | Chromium was present, but its headless process stalled before returning DOM output; no successful browser smoke result is claimed. |
| Physical iPhone 12 Safari test | Not run | No physical iPhone/Safari device is attached to this build environment. |
| iOS MediaRecorder / MP4 / audio export | Runtime-detected, not hardware verified | App checks support at runtime and reports failure rather than claiming it. |
| Offline installation | Implemented, not end-to-end verified here | Requires first successful online load and Service Worker cache population. |

## Known limitations / recommended next improvements

1. A true production-quality swap would need robust 3-D pose handling, occlusion segmentation, face parsing and more sophisticated texture synthesis. This implementation is a practical 2-D triangle warp.
2. The current source/target mesh correspondence relies on MediaPipe's consistent landmark indices; substantial yaw, pitch or expression differences can create stretching.
3. The renderer uses Canvas 2D rather than Three.js/WebGL to reduce mobile overhead. There is no custom GLSL shader path.
4. Multiple visible faces are flagged; there is no manual face selector or persistent identity tracker across cuts.
5. The preview is intentionally throttled. The exported render attempts to keep the selected frame rate, but synchronous Face Landmarker calls can make the recording slower than the video duration on an iPhone.
6. Browser support for recording and file sharing is not uniform. The UI only exposes export when MediaRecorder reports at least one supported type.

## Project structure

```text
face-swap-studio/
├── index.html
├── manifest.webmanifest
├── sw.js
├── README.md
├── package.json
├── css/styles.css
├── js/
│   ├── app.js
│   ├── face-engine.js
│   ├── face-alignment.js
│   ├── face-mesh.js
│   ├── stabilizer.js
│   ├── renderer.js
│   ├── color-matcher.js
│   ├── video-export.js
│   └── ui-controls.js
├── vendor/delaunator/delaunator.js
├── vendor/mediapipe/             # populated by scripts/fetch-assets.sh / GitHub Actions
├── models/                       # populated by scripts/fetch-assets.sh / GitHub Actions
├── scripts/fetch-assets.sh
├── tests/core.test.js
└── .github/workflows/pages.yml
```

## Official API and model references

- [MediaPipe Face Landmarker for Web](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/web_js)
- [MediaPipe Tasks Vision API](https://developers.google.com/edge/api/mediapipe/js/tasks-vision)
- [MediaPipe Face Landmarker model overview](https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker)
- [MediaPipe Tasks Vision npm package](https://www.npmjs.com/package/@mediapipe/tasks-vision)

## Privacy and consent

The app has no application backend, analytics or remote processing API. The only remote requests are for loading the static site and its first-install runtime/model assets from the hosting origin (and the official package/model downloads during the GitHub Actions build). The uploaded source image and target video are local browser `File` objects and object URLs. Use the tool only with appropriate permission and consent from the people depicted.
