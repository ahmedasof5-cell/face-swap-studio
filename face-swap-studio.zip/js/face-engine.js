/** Local-only MediaPipe Face Landmarker adapter with GPU -> CPU fallback. */
export class FaceEngine {
  constructor() { this.landmarker = null; this.delegate = '—'; this.mode = 'IMAGE'; }
  async initialize(onStatus = () => {}) {
    let vision;
    try {
      const module = await import('../vendor/mediapipe/vision_bundle.mjs');
      const wasmRoot = new URL('../vendor/mediapipe/wasm/', import.meta.url).href;
      const modelPath = new URL('../models/face_landmarker.task', import.meta.url).href;
      vision = await module.FilesetResolver.forVisionTasks(wasmRoot);
      onStatus('تهيئة محرك الرؤية…');
      const options = (delegate) => ({
        baseOptions: { modelAssetPath: modelPath, delegate },
        runningMode: 'IMAGE',
        numFaces: 2,
        minFaceDetectionConfidence: .55,
        minFacePresenceConfidence: .55,
        minTrackingConfidence: .55,
        outputFaceBlendshapes: true,
        outputFacialTransformationMatrixes: true
      });
      try {
        this.landmarker = await module.FaceLandmarker.createFromOptions(vision, options('GPU'));
        this.delegate = 'GPU';
      } catch (gpuError) {
        console.warn('MediaPipe GPU initialization failed; using CPU.', gpuError);
        onStatus('تعذر تشغيل GPU — جارٍ استخدام CPU…');
        this.landmarker = await module.FaceLandmarker.createFromOptions(vision, options('CPU'));
        this.delegate = 'CPU';
      }
      this.mode = 'IMAGE';
      return { delegate: this.delegate };
    } catch (error) {
      const detail = String(error?.message || error);
      if (/vision_bundle|Failed to fetch|404|not found/i.test(detail)) {
        throw new Error('أصول MediaPipe المحلية غير موجودة. شغّل خطوة تجهيز الأصول من README أو انشر عبر GitHub Actions.');
      }
      if (/face_landmarker\.task|model/i.test(detail)) throw new Error('ملف نموذج Face Landmarker غير موجود أو تعذّر تحميله.');
      throw new Error(`فشل تهيئة MediaPipe: ${detail}`);
    }
  }
  detectImage(image) {
    if (!this.landmarker) throw new Error('محرك الرؤية غير جاهز.');
    if (this.mode !== 'IMAGE') throw new Error('المحرك ليس في وضع الصور.');
    return this.landmarker.detect(image).faceLandmarks || [];
  }
  async setVideoMode() {
    if (!this.landmarker) throw new Error('محرك الرؤية غير جاهز.');
    if (this.mode !== 'VIDEO') { await this.landmarker.setOptions({ runningMode: 'VIDEO' }); this.mode = 'VIDEO'; }
  }
  detectVideo(video, timestampMs) {
    if (!this.landmarker || this.mode !== 'VIDEO') return [];
    return this.landmarker.detectForVideo(video, timestampMs).faceLandmarks || [];
  }
  close() { try { this.landmarker?.close(); } catch {} this.landmarker = null; }
}
