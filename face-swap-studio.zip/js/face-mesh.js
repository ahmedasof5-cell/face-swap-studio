import { triangulate } from '../vendor/delaunator/delaunator.js';
export const FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];
function pointInPolygon(p, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[i], b = polygon[j];
    if (((a.y > p.y) !== (b.y > p.y)) && p.x < (b.x-a.x) * (p.y-a.y) / ((b.y-a.y) || 1e-9) + a.x) inside = !inside;
  }
  return inside;
}
export function buildFaceMesh(sourceLandmarks, width, height) {
  const points = sourceLandmarks.slice(0, 468).map(p => [p.x * width, p.y * height]);
  const flat = points.flat();
  const raw = triangulate(flat);
  const oval = FACE_OVAL.map(i => ({ x: points[i][0], y: points[i][1] }));
  const maxEdge = Math.hypot(width, height) * .19;
  const triangles = [];
  for (let k = 0; k < raw.length; k += 3) {
    const ia=raw[k], ib=raw[k+1], ic=raw[k+2];
    const a=points[ia], b=points[ib], c=points[ic];
    const centroid={x:(a[0]+b[0]+c[0])/3,y:(a[1]+b[1]+c[1])/3};
    const edge=(p,q)=>Math.hypot(p[0]-q[0],p[1]-q[1]);
    if (pointInPolygon(centroid, oval) && edge(a,b)<maxEdge && edge(b,c)<maxEdge && edge(c,a)<maxEdge) triangles.push(ia,ib,ic);
  }
  if (triangles.length < 100) throw new Error('تعذر بناء شبكة الوجه من الصورة. جرّب صورة أمامية بإضاءة جيدة.');
  return { triangles: new Uint16Array(triangles), sourcePoints: points, count: triangles.length / 3 };
}
