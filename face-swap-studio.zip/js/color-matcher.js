const samplerCanvas = typeof document !== 'undefined' ? document.createElement('canvas') : null;
if (samplerCanvas) { samplerCanvas.width = 48; samplerCanvas.height = 48; }
function sampleLuma(source, box) {
  const ctx = samplerCanvas.getContext('2d', { willReadFrequently: true });
  const sx=Math.max(0,box.x), sy=Math.max(0,box.y), sw=Math.max(1,box.width), sh=Math.max(1,box.height);
  ctx.drawImage(source,sx,sy,sw,sh,0,0,48,48);
  const data=ctx.getImageData(0,0,48,48).data;let sum=0,sum2=0,count=0;
  for(let i=0;i<data.length;i+=4){const l=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];sum+=l;sum2+=l*l;count++;}
  const mean=sum/count;return {mean,std:Math.sqrt(Math.max(0,sum2/count-mean*mean))};
}
export function getFaceBounds(points) {
  const xs=points.map(p=>p.x),ys=points.map(p=>p.y);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
  return {x:minX,y:minY,width:Math.max(1,maxX-minX),height:Math.max(1,maxY-minY)};
}
export function calculateColorFilter(source, video, sourcePoints, targetPoints, strength=0.65) {
  try{
    const s=sampleLuma(source,getFaceBounds(sourcePoints));
    const t=sampleLuma(video,getFaceBounds(targetPoints));
    const amount=Math.max(0,Math.min(1,strength));
    const ratio=Math.max(.82,Math.min(1.22,t.mean/Math.max(1,s.mean)));
    const contrast=Math.max(.88,Math.min(1.15,t.std/Math.max(4,s.std)));
    const brightness=1+(ratio-1)*amount;
    const contrastOut=1+(contrast-1)*amount;
    return `brightness(${brightness.toFixed(3)}) contrast(${contrastOut.toFixed(3)}) saturate(${(1-.10*amount).toFixed(3)})`;
  }catch{return 'none';}
}
