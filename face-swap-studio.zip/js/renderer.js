import { alignFace, expandFaceOutline } from './face-alignment.js';
import { calculateColorFilter } from './color-matcher.js';

function makeCanvas() { return typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(2,2) : Object.assign(document.createElement('canvas'),{width:2,height:2}); }
function affineFromTriangles(s0,s1,s2,d0,d1,d2) {
  const x0=s0[0],y0=s0[1],x1=s1[0],y1=s1[1],x2=s2[0],y2=s2[1];
  const den=x0*(y1-y2)+x1*(y2-y0)+x2*(y0-y1);
  if(Math.abs(den)<1e-7) return null;
  const solve=(v0,v1,v2)=>{
    const a=(v0*(y1-y2)+v1*(y2-y0)+v2*(y0-y1))/den;
    const c=(v0*(x2-x1)+v1*(x0-x2)+v2*(x1-x0))/den;
    const e=(v0*(x1*y2-x2*y1)+v1*(x2*y0-x0*y2)+v2*(x0*y1-x1*y0))/den;
    return [a,c,e];
  };
  const [a,c,e]=solve(d0[0],d1[0],d2[0]);const [b,d,f]=solve(d0[1],d1[1],d2[1]);
  return {a,b,c,d,e,f};
}
function drawTriangle(ctx, image, sourcePoints, targetPoints, ia, ib, ic) {
  const s0=sourcePoints[ia],s1=sourcePoints[ib],s2=sourcePoints[ic];
  const d0=targetPoints[ia],d1=targetPoints[ib],d2=targetPoints[ic];
  if(!s0||!s1||!s2||!d0||!d1||!d2) return;
  const m=affineFromTriangles(s0,s1,s2,d0,d1,d2);if(!m)return;
  ctx.save();ctx.beginPath();ctx.moveTo(d0.x,d0.y);ctx.lineTo(d1.x,d1.y);ctx.lineTo(d2.x,d2.y);ctx.closePath();ctx.clip();
  ctx.setTransform(m.a,m.b,m.c,m.d,m.e,m.f);ctx.drawImage(image,0,0);ctx.restore();
}
export class FaceRenderer {
  constructor(canvas) {
    this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:false,desynchronized:true});
    this.patch=makeCanvas();this.patchCtx=this.patch.getContext('2d');this.mask=makeCanvas();this.maskCtx=this.mask.getContext('2d');
    this.lastResult=null;this.showLandmarks=false;
  }
  resize(width,height,maxHeight=720) {
    const scale=Math.min(1,maxHeight/height,1280/width);const w=Math.max(2,Math.floor(width*scale/2)*2),h=Math.max(2,Math.floor(height*scale/2)*2);
    for(const c of [this.canvas,this.patch,this.mask]){c.width=w;c.height=h;}
    this.ctx=this.canvas.getContext('2d',{alpha:false,desynchronized:true});this.patchCtx=this.patch.getContext('2d');this.maskCtx=this.mask.getContext('2d');
    this.width=w;this.height=h;return {width:w,height:h,scaleX:w/width,scaleY:h/height};
  }
  render(video,sourceImage,sourceLandmarks,targetLandmarks,mesh,settings={}) {
    if(!this.width||!this.height)this.resize(video.videoWidth,video.videoHeight);
    const w=this.width,h=this.height,ctx=this.ctx;
    ctx.setTransform(1,0,0,1,0,0);ctx.filter='none';ctx.globalAlpha=1;ctx.drawImage(video,0,0,w,h);
    if(sourceLandmarks&&targetLandmarks&&mesh){
      const targetPx=targetLandmarks.map(p=>({x:p.x*w,y:p.y*h,z:p.z??0}));
      const aligned=alignFace(sourceLandmarks,targetLandmarks,w,h,{
        identityLock:(settings.identityLock??72)/100,faceScale:(settings.faceScale??100)/100,
        xOffset:settings.xOffset??0,yOffset:settings.yOffset??0
      });
      const points=aligned.points;
      this.patchCtx.setTransform(1,0,0,1,0,0);this.patchCtx.clearRect(0,0,w,h);
      this.patchCtx.globalAlpha=1;this.patchCtx.filter=calculateColorFilter(sourceImage,video,
        mesh.sourcePoints.map(p=>({x:p[0],y:p[1]})),targetLandmarks.map(p=>({x:p.x*video.videoWidth,y:p.y*video.videoHeight})),(settings.colorStrength??65)/100);
      for(let i=0;i<mesh.triangles.length;i+=3) drawTriangle(this.patchCtx,sourceImage,mesh.sourcePoints,points,mesh.triangles[i],mesh.triangles[i+1],mesh.triangles[i+2]);
      this.patchCtx.filter='none';
      const outline=expandFaceOutline(points,{beardExpansion:(settings.beardExpansion??18)/100,foreheadExpansion:(settings.foreheadExpansion??12)/100});
      this.maskCtx.setTransform(1,0,0,1,0,0);this.maskCtx.clearRect(0,0,w,h);this.maskCtx.fillStyle='#fff';
      this.maskCtx.filter=`blur(${Math.max(0,settings.edgeFeather??8)*Math.max(.35,w/960)}px)`;
      this.maskCtx.beginPath();outline.forEach((p,i)=>i?this.maskCtx.lineTo(p.x,p.y):this.maskCtx.moveTo(p.x,p.y));this.maskCtx.closePath();this.maskCtx.fill();this.maskCtx.filter='none';
      this.patchCtx.globalCompositeOperation='destination-in';this.patchCtx.drawImage(this.mask,0,0,w,h);this.patchCtx.globalCompositeOperation='source-over';
      ctx.save();ctx.globalAlpha=(settings.opacity??96)/100;ctx.drawImage(this.patch,0,0,w,h);ctx.restore();
      if(this.showLandmarks){ctx.save();ctx.fillStyle='#72efe0';for(let i=0;i<targetPx.length;i+=4){ctx.beginPath();ctx.arc(targetPx[i].x,targetPx[i].y,1.3,0,Math.PI*2);ctx.fill();}ctx.restore();}
      this.lastResult={points,outline};return this.lastResult;
    }
    return null;
  }
  dispose(){for(const c of [this.patch,this.mask]){c.width=1;c.height=1;}this.canvas.width=2;this.canvas.height=2;}
}
