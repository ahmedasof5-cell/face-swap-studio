const CONTROL_IDS = ['identityLock','faceScale','xOffset','yOffset','beardExpansion','foreheadExpansion','opacity','edgeFeather','colorStrength','motionSmoothing'];
const VALUE_IDS = {identityLock:'identityValue',faceScale:'scaleValue',xOffset:'xValue',yOffset:'yValue',beardExpansion:'beardValue',foreheadExpansion:'foreheadValue',opacity:'opacityValue',edgeFeather:'featherValue',colorStrength:'colorValue',motionSmoothing:'smoothValue'};
export const DEFAULT_SETTINGS = Object.freeze({identityLock:72,faceScale:100,xOffset:0,yOffset:0,beardExpansion:18,foreheadExpansion:12,opacity:96,edgeFeather:8,colorStrength:65,motionSmoothing:55});
export function readControls() { const out={};for(const id of CONTROL_IDS){const el=document.getElementById(id);out[id]=Number(el.value);}return out; }
export function bindControls(onChange) {
  for(const id of CONTROL_IDS){const el=document.getElementById(id),output=document.getElementById(VALUE_IDS[id]);
    const update=()=>{const v=Number(el.value);output.textContent=id==='edgeFeather'?`${v} px`:id==='xOffset'||id==='yOffset'?String(v):`${v}%`;onChange(readControls());};
    el.addEventListener('input',update);update();
  }
  document.getElementById('resetControls').addEventListener('click',()=>{
    for(const [id,value] of Object.entries(DEFAULT_SETTINGS))document.getElementById(id).value=String(value);
    for(const id of CONTROL_IDS)document.getElementById(id).dispatchEvent(new Event('input',{bubbles:true}));
  });
}
