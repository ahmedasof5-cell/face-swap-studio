const MIME_CANDIDATES = [
  'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4',
  'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'
];
export function supportedRecordingTypes() {
  if (!('MediaRecorder' in window) || typeof MediaRecorder.isTypeSupported !== 'function') return [];
  return MIME_CANDIDATES.filter(type => MediaRecorder.isTypeSupported(type));
}
export class VideoExporter {
  constructor() { this.audioContext = null; this.audioSource = null; }
  async getAudioTrack(video) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    try {
      if (!this.audioContext) this.audioContext = new AudioCtx();
      if (this.audioContext.state === 'suspended') await this.audioContext.resume();
      if (!this.audioSource) this.audioSource = this.audioContext.createMediaElementSource(video);
      const destination = this.audioContext.createMediaStreamDestination();
      this.audioSource.connect(destination);
      return { track: destination.stream.getAudioTracks()[0] || null, cleanup: () => { try { this.audioSource.disconnect(destination); } catch {} } };
    } catch (error) { console.warn('Original audio could not be attached:', error); return null; }
  }
  async export({ video, canvas, processFrame, outputFps = 30, bitrate = 3000000, onProgress = () => {}, onStatus = () => {} }) {
    if (!('MediaRecorder' in window)) throw new Error('MediaRecorder غير مدعوم في هذا المتصفح.');
    if (typeof canvas.captureStream !== 'function') throw new Error('Canvas captureStream غير متاح في هذا المتصفح.');
    const types = supportedRecordingTypes();
    if (!types.length) throw new Error('لم يعثر المتصفح على صيغة تسجيل مدعومة (MP4 أو WebM).');
    const mimeType = types.find(t => t.startsWith('video/mp4')) || types[0];
    const stream = canvas.captureStream(outputFps);
    const oldMuted = video.muted, oldLoop = video.loop, oldRate = video.playbackRate;
    video.muted = false;
    const audio = await this.getAudioTrack(video);
    if (audio?.track) stream.addTrack(audio.track);
    let recorder;
    try { recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: bitrate, audioBitsPerSecond: 128000 }); }
    catch (error) { stream.getTracks().forEach(t => t.stop()); audio?.cleanup?.(); video.muted=oldMuted;video.loop=oldLoop;video.playbackRate=oldRate; throw new Error(`تعذر بدء التسجيل بهذه الصيغة: ${error.message}`); }
    const chunks = [];
    let frameHandle = null, settled = false;
    const resultPromise = new Promise((resolve, reject) => {
      const cleanup = () => {
        settled = true;
        if (frameHandle != null) { if (video.cancelVideoFrameCallback) video.cancelVideoFrameCallback(frameHandle); else cancelAnimationFrame(frameHandle); }
        video.onended = null; video.onerror = null;
        stream.getTracks().forEach(t => t.stop()); audio?.cleanup?.();
        video.muted = oldMuted; video.loop = oldLoop; video.playbackRate = oldRate;
      };
      recorder.ondataavailable = event => { if (event.data?.size) chunks.push(event.data); };
      recorder.onerror = event => { if (settled) return; cleanup(); reject(event.error || new Error('حدث خطأ أثناء تسجيل الفيديو.')); };
      recorder.onstop = () => {
        if (settled) return;
        cleanup();
        if (!chunks.length) { reject(new Error('انتهى التسجيل دون إنشاء بيانات فيديو.')); return; }
        const blob = new Blob(chunks, { type: mimeType });
        if (blob.size < 1024) { reject(new Error('ملف التصدير الناتج فارغ أو غير مكتمل.')); return; }
        resolve({ blob, mimeType, extension: mimeType.startsWith('video/mp4') ? 'mp4' : 'webm' });
      };
      video.onended = () => { onProgress(1); if (recorder.state !== 'inactive') recorder.stop(); };
      video.onerror = () => { if (recorder.state !== 'inactive') recorder.stop(); reject(new Error('تعذّر فك ترميز الفيديو أثناء التصدير.')); };
      const pump = (now) => {
        if (settled || recorder.state === 'inactive') return;
        try { processFrame(now || performance.now()); } catch (error) { if (recorder.state !== 'inactive') recorder.stop(); reject(error); return; }
        const duration = Math.max(.01, video.duration || 1);
        onProgress(Math.min(1, video.currentTime / duration));
        if (video.requestVideoFrameCallback) frameHandle = video.requestVideoFrameCallback(pump);
        else frameHandle = requestAnimationFrame(pump);
      };
      try {
        recorder.start(1000);
        video.loop = false; video.muted = false; video.playbackRate = 1;
        video.currentTime = 0;
        const begin = () => {
          video.play().then(() => {
            processFrame(performance.now());
            if (video.requestVideoFrameCallback) frameHandle = video.requestVideoFrameCallback(pump);
            else frameHandle = requestAnimationFrame(pump);
            onStatus('جارٍ تسجيل الإطارات…');
          }).catch(error => { if (recorder.state !== 'inactive') recorder.stop(); reject(new Error(`تعذّر تشغيل الفيديو للتصدير: ${error.message}`)); });
        };
        if (video.readyState >= 2) begin(); else video.addEventListener('canplay', begin, { once: true });
      } catch (error) { if (recorder.state !== 'inactive') recorder.stop(); reject(error); }
    });
    try { const result = await resultPromise; return result; }
    catch (error) { throw error; }
  }
  async dispose() { try { await this.audioContext?.close(); } catch {} this.audioContext = null; this.audioSource = null; }
}
