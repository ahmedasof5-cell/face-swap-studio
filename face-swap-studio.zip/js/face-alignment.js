/**
 * 2-D Procrustes similarity alignment. A least-squares similarity transform is
 * solved from stable eye/nose/temple anchors. Expression transfer is then added
 * as a bounded residual, not a wholesale per-landmark warp.
 */
export const ALIGNMENT_ANCHORS = [33, 263, 168, 1, 127, 356, 10, 152];
export function solveSimilarity(source, target, anchorIds = ALIGNMENT_ANCHORS) {
  const ids = anchorIds.filter(i => source[i] && target[i]);
  if (ids.length < 3) throw new Error('لا توجد نقاط كافية لمحاذاة الوجه.');
  const mean = (pts, key) => ids.reduce((s, i) => s + pts[i][key], 0) / ids.length;
  const sx = mean(source, 'x'), sy = mean(source, 'y'), tx = mean(target, 'x'), ty = mean(target, 'y');
  let dot = 0, cross = 0, denom = 0;
  for (const i of ids) {
    const x = source[i].x - sx, y = source[i].y - sy;
    const u = target[i].x - tx, v = target[i].y - ty;
    dot += x * u + y * v; cross += x * v - y * u; denom += x * x + y * y;
  }
  if (denom < 1e-8) throw new Error('تعذر تقدير حجم الوجه.');
  const a = dot / denom, b = cross / denom;
  const scale = Math.hypot(a, b);
  const rotation = Math.atan2(b, a);
  return { a, b, scale, rotation, tx: tx - (a * sx - b * sy), ty: ty - (b * sx + a * sy) };
}
export function applySimilarity(point, t) {
  return { x: t.a * point.x - t.b * point.y + t.tx, y: t.b * point.x + t.a * point.y + t.ty, z: point.z ?? 0 };
}
export function alignFace(source, target, frameWidth, frameHeight, settings = {}) {
  if (!source || !target || source.length < 468 || target.length < 468) throw new Error('يجب أن يحتوي كل وجه على 468 نقطة على الأقل.');
  const src = source.map(p => ({ x: p.x * frameWidth, y: p.y * frameHeight, z: p.z ?? 0 }));
  const dst = target.map(p => ({ x: p.x * frameWidth, y: p.y * frameHeight, z: p.z ?? 0 }));
  const transform = solveSimilarity(src, dst);
  const identity = Math.max(0, Math.min(1, settings.identityLock ?? .72));
  const expressionWeight = 1 - identity;
  const scale = (settings.faceScale ?? 1);
  const anchorCenter = { x: dst[168].x, y: dst[168].y };
  const faceWidth = Math.max(30, Math.abs(dst[263].x - dst[33].x));
  const offsetX = (settings.xOffset ?? 0) * faceWidth / 100;
  const offsetY = (settings.yOffset ?? 0) * faceWidth / 100;
  const mapped = src.slice(0, 468).map((p, i) => {
    const rigid = applySimilarity(p, transform);
    let dx = dst[i].x - rigid.x, dy = dst[i].y - rigid.y;
    const limit = faceWidth * .12;
    const magnitude = Math.hypot(dx, dy);
    if (magnitude > limit) { dx *= limit / magnitude; dy *= limit / magnitude; }
    let x = anchorCenter.x + (rigid.x - anchorCenter.x) * scale + dx * expressionWeight + offsetX;
    let y = anchorCenter.y + (rigid.y - anchorCenter.y) * scale + dy * expressionWeight + offsetY;
    return { x, y };
  });
  return { points: mapped, transform, faceWidth, faceHeight: Math.abs(dst[152].y - dst[10].y), center: anchorCenter };
}
export function expandFaceOutline(points, settings = {}) {
  const ids = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];
  const outline = ids.map(i => points[i]).filter(Boolean);
  if (outline.length < 3) return outline;
  const cx = outline.reduce((s,p)=>s+p.x,0)/outline.length, cy = outline.reduce((s,p)=>s+p.y,0)/outline.length;
  const beard = (settings.beardExpansion ?? .18), forehead = (settings.foreheadExpansion ?? .12);
  return outline.map(p => {
    const lower = p.y > cy;
    const vertical = 1 + (lower ? beard : forehead) * .78;
    const horizontal = 1 + (lower ? beard : forehead) * .12;
    return { x: cx + (p.x - cx) * horizontal, y: cy + (p.y - cy) * vertical };
  });
}
