import { FaceEngine } from './face-engine.js';
import { buildFaceMesh } from './face-mesh.js';
import { LandmarkStabilizer } from './stabilizer.js';
import { FaceRenderer } from './renderer.js';
import { VideoExporter, supportedRecordingTypes } from './video-export.js';
import { bindControls, readControls } from './ui-controls.js';

const $ = id => document.getElementById(id);
const state = { sourceFile:null, videoFile:null, sourceUrl:null, videoUrl:null, sourceImage:null, sourceLandmarks:null, mesh:null, duration:0, renderer:null, engine:null, stabilizer:new LandmarkStabilizer(), exporter:new VideoExporter(), raf:null, lastVideoTime:-1, lastDetectAt:0, lastTarget:null, fpsSamples:[], outputBlob:null, outputUrl:null, processing:false, exporting:false, settings:readControls(), lastTimestamp:0 };
const video=$('targetVideo'),canvas=$('outputCanvas');state.renderer=new FaceRenderer(canvas);

function toast(message, duration=4200){const node=$('toast');node.textContent=message;node.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>node.classList.remove('show'),duration);}
function setStatus(message, level='idle'){$('topStatus').textContent=message;$('statusDot').className=`status-dot ${level==='ok'?'ok':level==='bad'?'bad':''}`;}
function setHint(message){$('trackingHint').textContent=message;}
function formatTime(seconds){if(!Number.isFinite(seconds))return '00:00';const s=Math.max(0,Math.floor(seconds));return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
function setProgress(value,label){const pct=Math.max(0,Math.min(100,value*100));$('progressBar').style.width=`${pct}%`;if(label)$('progressLabel').textContent=label;}
function getFaceImage(file){const url=URL.createObjectURL(file);return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve({image:img,url});img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('تعذّر فتح صورة الوجه.'));};img.src=url;});}
function clearOutput(){if(state.outputUrl)URL.revokeObjectURL(state.outputUrl);state.outputUrl=null;state.outputBlob=null;$('finalVideo').pause();$('finalVideo').hidden=true;$('finalVideo').removeAttribute('src');$('finalVideo').load();$('downloadBtn').classList.add('disabled-link');$('downloadBtn').setAttribute('aria-disabled','true');$('shareBtn').disabled=true;}
function cleanupInputUrls(){if(state.sourceUrl)URL.revokeObjectURL(state.sourceUrl);if(state.videoUrl)URL.revokeObjectURL(state.videoUrl);state.sourceUrl=state.videoUrl=null;}
function validateReady(){const ready=!!(state.sourceFile&&state.videoFile);$('analyzeBtn').disabled=!ready;}
function invalidateProcessing(){
  if(!state.processing&&!state.engine)return;
  pausePreview();state.processing=false;state.engine?.close();state.engine=null;state.stabilizer.reset();state.lastTarget=null;state.lastVideoTime=-1;state.lastDetectAt=0;state.sourceLandmarks=null;state.mesh=null;clearOutput();$('emptyState').hidden=false;$('playBtn').disabled=$('pauseBtn').disabled=true;$('exportBtn').disabled=true;$('analyzeBtn').textContent='✦ تحليل الوجه وبدء المعاينة';setStatus('تم تحديث الملفات');setHint('تغيّرت ملفات المشروع. أعد تحليل الوجه لبدء المعاينة.');
}
function updateCapabilityStatus(){
  const types=supportedRecordingTypes();
  $('engineStatus').textContent='ينتظر تحميل الأصول';$('engineDetail').textContent='MediaPipe محلي — IMAGE / VIDEO';
  $('gpuStatus').textContent=('gpu' in navigator)?'قيد التحقق':'CPU / تلقائي';$('gpuDetail').textContent='GPU ثم CPU عند الحاجة';
  $('exportStatus').textContent=types.length?'متاح مبدئياً':'غير مدعوم';$('exportDetail').textContent=types.join(' · ')||'لا يوجد MediaRecorder صالح';
  $('mimeBadge').textContent=types.length?types[0]:'لا توجد صيغة تسجيل';$('exportBtn').disabled=!state.processing||!types.length;
}
function loadFileInputs(){
  $('sourceInput').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    if(!/^image\/(jpeg|png|webp)$/.test(file.type)){toast('صيغة الصورة غير مدعومة. استخدم JPG أو PNG أو WEBP.');e.target.value='';return;}
    if(file.size>20*1024*1024){toast('حجم الصورة كبير. الحد المقترح 20MB.');return;}
    invalidateProcessing();
    if(state.sourceUrl)URL.revokeObjectURL(state.sourceUrl);
    state.sourceFile=file;
    try{const loaded=await getFaceImage(file);state.sourceImage=loaded.image;state.sourceUrl=loaded.url;const old=$('sourcePreview').querySelector('img');old?.remove();const thumb=document.createElement('img');thumb.src=loaded.url;$('sourcePreview').append(thumb);$('sourceName').textContent=file.name;$('fileValidation').textContent='تم تحميل صورة الوجه.';validateReady();}catch(err){state.sourceFile=null;toast(err.message);validateReady();}
  });
  $('videoInput').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    if(!file.type.startsWith('video/')&&!/\.(mp4|mov|webm)$/i.test(file.name)){toast('اختر فيديو MP4 أو MOV أو WEBM.');e.target.value='';return;}
    if(file.size>300*1024*1024){toast('حجم الفيديو يتجاوز 300MB. اختر مقطعاً أخف لتقليل استهلاك الذاكرة.');return;}
    invalidateProcessing();
    if(state.videoUrl)URL.revokeObjectURL(state.videoUrl);
    state.videoFile=file;state.videoUrl=URL.createObjectURL(file);video.src=state.videoUrl;video.load();
    try{await new Promise((resolve,reject)=>{if(video.readyState>=1)return resolve();video.addEventListener('loadedmetadata',resolve,{once:true});video.addEventListener('error',()=>reject(new Error('هذا الترميز غير مدعوم في المتصفح.')),{once:true});});
      state.duration=video.duration;
      if(!Number.isFinite(state.duration)||state.duration<=0)throw new Error('تعذّر قراءة مدة الفيديو.');
      if(state.duration>30.05)throw new Error('مدة الفيديو أطول من 30 ثانية. قصّ المقطع ثم أعد رفعه.');
      $('videoName').textContent=file.name;$('videoMeta').textContent=`${formatTime(state.duration)} · ${video.videoWidth}×${video.videoHeight}`;$('fileValidation').textContent='تم تحميل الفيديو وقراءة البيانات الوصفية.';
      if(video.readyState<2)await new Promise(resolve=>video.addEventListener('loadeddata',resolve,{once:true}));
      const poster=document.createElement('canvas');poster.width=160;poster.height=90;const ctx=poster.getContext('2d');ctx.drawImage(video,0,0,160,90);const preview=$('videoPreview');preview.innerHTML='';const thumb=document.createElement('img');thumb.src=poster.toDataURL('image/jpeg',.7);thumb.style.cssText='width:56px;height:44px;object-fit:cover;border-radius:9px;border:1px solid #ffffff24';preview.append(thumb);
      $('durationTime').textContent=formatTime(state.duration);$('timeline').disabled=false;$('timeline').max=String(state.duration);validateReady();
    }catch(err){state.videoFile=null;toast(err.message);$('videoMeta').textContent='فشل تحميل الفيديو';validateReady();}
  });
}

async function analyzeProject(){
  if(state.processing||!state.sourceImage||!state.videoFile)return;
  state.processing=true;$('analyzeBtn').disabled=true;$('analyzeBtn').textContent='جارٍ تحليل المشروع…';setStatus('تحميل محرك الرؤية');setHint('تحميل ملفات MediaPipe المحلية والنموذج…');
  try{
    state.engine?.close();state.engine=new FaceEngine();
    const hardware=await state.engine.initialize(message=>setHint(message));
    $('engineStatus').textContent='يعمل';$('engineDetail').textContent=`Face Landmarker · ${hardware.delegate}`;$('gpuStatus').textContent=hardware.delegate;$('gpuDetail').textContent=hardware.delegate==='GPU'?'تسريع رسومي متاح':'معالجة CPU فعّالة';
    const sourceFaces=state.engine.detectImage(state.sourceImage);
    if(sourceFaces.length===0)throw new Error('لم يتم اكتشاف وجه في الصورة الأصلية. اختر صورة أمامية واضحة.');
    if(sourceFaces.length>1)throw new Error('تحتوي صورة المصدر على أكثر من وجه. ارفع صورة يظهر فيها وجه واحد فقط.');
    state.sourceLandmarks=sourceFaces[0];
    state.mesh=buildFaceMesh(state.sourceLandmarks,state.sourceImage.naturalWidth,state.sourceImage.naturalHeight);
    await state.engine.setVideoMode();
    state.stabilizer.reset();state.lastTarget=null;state.lastVideoTime=-1;state.lastDetectAt=0;
    const dims=state.renderer.resize(video.videoWidth,video.videoHeight,Number($('resolutionSelect').value));
    $('previewDimensions').textContent=`${dims.width} × ${dims.height}`;$('emptyState').hidden=true;
    video.loop=true;video.muted=true;video.currentTime=0;
    await new Promise(resolve=>{if(video.readyState>=2)resolve();else video.addEventListener('loadeddata',resolve,{once:true});});
    processFrame(performance.now());
    $('playBtn').disabled=false;$('pauseBtn').disabled=false;$('timeline').disabled=false;$('exportBtn').disabled=!supportedRecordingTypes().length;
    state.processing=true;setStatus('تتبع الوجه نشط','ok');setHint(`تم تحليل المصدر وبناء شبكة من ${state.mesh.count} مثلثاً. ابدأ التشغيل للمعاينة.`);setProgress(0,'تم تجهيز المشروع');
    await video.play().catch(()=>{});startPreviewLoop();toast('تم تجهيز المشروع. راجع المعاينة واضبط القيم قبل التصدير.');
  }catch(err){state.processing=false;state.engine?.close();state.engine=null;setStatus('تعذّر بدء التحليل','bad');setHint(err.message);toast(err.message,6500);$('analyzeBtn').disabled=false;}
  finally{$('analyzeBtn').textContent='✦ تحليل الوجه وبدء المعاينة';updateCapabilityStatus();}
}

function processFrame(now){
  if(!state.processing||!state.engine||!state.sourceLandmarks||!state.mesh||video.readyState<2)return;
  const t=video.currentTime;if(t===state.lastVideoTime)return;
  state.lastVideoTime=t;
  const timestamp=Math.max(now||performance.now(),state.lastTimestamp+1);state.lastTimestamp=timestamp;
  let results=null;
  const previewThrottleMs=110;
  if(state.exporting || timestamp-state.lastDetectAt>=previewThrottleMs || !state.lastTarget){
    results=state.engine.detectVideo(video,timestamp);state.lastDetectAt=timestamp;
  }
  let target=state.lastTarget;
  if(results && results.length>1){setHint('تم اكتشاف أكثر من وجه في هذا الإطار. استخدم مقطعاً بوجه منفرد للحصول على نتيجة مستقرة.');target=state.stabilizer.hold(2);state.lastTarget=target;}
  else if(results && results.length===1){target=state.stabilizer.process(results[0],timestamp/1000,state.settings.motionSmoothing/100);state.lastTarget=target;}
  else if(results && results.length===0){target=state.stabilizer.hold(5);state.lastTarget=target;if(!target)setHint('لم يتم العثور على الوجه في هذا الإطار؛ سيعود التتبع عند ظهوره.');}
  if(target){state.renderer.showLandmarks=$('landmarksToggle').getAttribute('aria-pressed')==='true';state.renderer.render(video,state.sourceImage,state.sourceLandmarks,target,state.mesh,state.settings);}
  else {const ctx=canvas.getContext('2d');ctx.drawImage(video,0,0,canvas.width,canvas.height);}
  state.fpsSamples.push(now||performance.now());if(state.fpsSamples.length>12)state.fpsSamples.shift();
  if(state.fpsSamples.length>2){const fps=(state.fpsSamples.length-1)*1000/(state.fpsSamples.at(-1)-state.fpsSamples[0]);$('fpsLabel').textContent=`${Math.round(fps)} FPS`;}
  $('currentTime').textContent=formatTime(t);$('timeline').value=String(t);setProgress(t/Math.max(.01,state.duration),`معاينة ${formatTime(t)} / ${formatTime(state.duration)}`);
}
function startPreviewLoop(){stopPreviewLoop();const tick=now=>{if(!state.processing||state.exporting)return;try{if(!video.paused&&video.currentTime!==state.lastVideoTime)processFrame(now);}catch(err){console.error(err);setHint(`تعذّرت معالجة الإطار: ${err.message}`);}state.raf=requestAnimationFrame(tick);};state.raf=requestAnimationFrame(tick);}
function stopPreviewLoop(){if(state.raf!==null)cancelAnimationFrame(state.raf);state.raf=null;}
function pausePreview(){video.pause();stopPreviewLoop();$('playBtn').textContent='▶ تشغيل';}
async function playPreview(){try{video.muted=true;await video.play();$('playBtn').textContent='Ⅱ يعمل';startPreviewLoop();}catch{toast('اضغط تشغيل مرة أخرى للسماح بتشغيل الفيديو.');}}

function bindEvents(){
  $('analyzeBtn').addEventListener('click',analyzeProject);
  $('playBtn').addEventListener('click',playPreview);$('pauseBtn').addEventListener('click',pausePreview);
  $('timeline').addEventListener('input',()=>{pausePreview();video.currentTime=Number($('timeline').value);});
  video.addEventListener('seeked',()=>{if(state.processing){state.lastVideoTime=-1;try{processFrame(performance.now());}catch{}}});
  $('landmarksToggle').addEventListener('click',()=>{const btn=$('landmarksToggle');const on=btn.getAttribute('aria-pressed')!=='true';btn.setAttribute('aria-pressed',String(on));btn.textContent=on?'إخفاء النقاط':'إظهار النقاط';state.renderer.showLandmarks=on;if(state.lastTarget)state.renderer.render(video,state.sourceImage,state.sourceLandmarks,state.lastTarget,state.mesh,state.settings);});
  bindControls(settings=>{state.settings=settings;if(state.processing&&state.lastTarget&&video.readyState>=2){try{state.renderer.render(video,state.sourceImage,state.sourceLandmarks,state.lastTarget,state.mesh,state.settings);}catch(err){console.warn(err);}}});
  $('resolutionSelect').addEventListener('change',()=>{if(video.videoWidth&&state.processing){const d=state.renderer.resize(video.videoWidth,video.videoHeight,Number($('resolutionSelect').value));$('previewDimensions').textContent=`${d.width} × ${d.height}`;state.lastVideoTime=-1;processFrame(performance.now());}});
  $('exportBtn').addEventListener('click',exportProject);$('shareBtn').addEventListener('click',shareOutput);
  $('resetBtn').addEventListener('click',resetProject);
  $('installHelp').addEventListener('click',()=>$('infoDialog').showModal());$('closeDialog').addEventListener('click',()=>$('infoDialog').close());$('dialogOk').addEventListener('click',()=>$('infoDialog').close());
  $('downloadBtn').addEventListener('click',e=>{if(!state.outputUrl)e.preventDefault();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.processing&&!state.exporting)pausePreview();});
  window.addEventListener('pagehide',()=>{stopPreviewLoop();});
}

async function exportProject(){
  if(!state.processing||state.exporting)return;
  if(!supportedRecordingTypes().length){toast('متصفحك لا يدعم MediaRecorder لصيغ الفيديو المتاحة.');return;}
  state.exporting=true;stopPreviewLoop();pausePreview();$('exportBtn').disabled=true;$('exportProgressText').textContent='تهيئة التسجيل…';setStatus('تصدير الفيديو');
  clearOutput();
  const dims=state.renderer.resize(video.videoWidth,video.videoHeight,Number($('resolutionSelect').value));$('previewDimensions').textContent=`${dims.width} × ${dims.height}`;state.lastVideoTime=-1;
  const quality=$('qualitySelect').value;const bitrate=quality==='high'?5000000:quality==='compact'?1500000:3000000;const fps=Number($('fpsSelect').value);
  try{
    const result=await state.exporter.export({video,canvas,outputFps:fps,bitrate,
      processFrame:now=>{state.lastVideoTime=-1;processFrame(now);},
      onProgress:p=>{$('exportProgressBar').style.width=`${Math.round(p*100)}%`;$('exportProgressPct').textContent=`${Math.round(p*100)}%`;$('exportProgressText').textContent=`تسجيل ${formatTime(video.currentTime)} من ${formatTime(state.duration)}`;},
      onStatus:message=>{$('exportProgressText').textContent=message;}
    });
    state.outputBlob=result.blob;state.outputUrl=URL.createObjectURL(result.blob);const fileName=`face-swap-studio.${result.extension}`;
    $('downloadBtn').href=state.outputUrl;$('downloadBtn').download=fileName;$('downloadBtn').classList.remove('disabled-link');$('downloadBtn').removeAttribute('aria-disabled');$('shareBtn').disabled=false;
    $('finalVideo').src=state.outputUrl;$('finalVideo').hidden=false;$('exportProgressText').textContent=`اكتمل التصدير · ${(result.blob.size/1024/1024).toFixed(1)} MB`;$('exportProgressPct').textContent='100%';$('exportProgressBar').style.width='100%';
    toast(`اكتمل الفيديو بصيغة ${result.extension.toUpperCase()}.`);setStatus('اكتمل التصدير','ok');
  }catch(err){console.error(err);$('exportProgressText').textContent=err.message;toast(err.message,7000);setStatus('فشل التصدير','bad');}
  finally{state.exporting=false;video.loop=true;video.muted=true;state.lastVideoTime=-1;try{processFrame(performance.now());}catch{}if(!video.paused)startPreviewLoop();$('exportBtn').disabled=!state.processing||!supportedRecordingTypes().length;}
}
async function shareOutput(){
  if(!state.outputBlob)return;
  const ext=state.outputBlob.type.includes('mp4')?'mp4':'webm';const file=new File([state.outputBlob],`face-swap-studio.${ext}`,{type:state.outputBlob.type});
  try{
    if(navigator.canShare?.({files:[file]})&&navigator.share){await navigator.share({files:[file],title:'Face Swap Studio video'});}
    else if(navigator.share){await navigator.share({title:'Face Swap Studio video',url:state.outputUrl});}
    else {toast('المشاركة المباشرة غير مدعومة. استخدم زر تنزيل الملف ثم احفظه في تطبيق الملفات أو الصور.');}
  }catch(err){if(err.name!=='AbortError')toast(`تعذّرت المشاركة: ${err.message}`);}
}
function resetProject(){
  pausePreview();stopPreviewLoop();state.processing=false;state.exporting=false;state.stabilizer.reset();state.engine?.close();state.engine=null;state.sourceFile=state.videoFile=state.sourceImage=state.sourceLandmarks=state.mesh=null;state.lastTarget=null;state.duration=0;state.lastVideoTime=-1;state.lastDetectAt=0;
  cleanupInputUrls();clearOutput();video.removeAttribute('src');video.load();$('sourceInput').value='';$('videoInput').value='';$('sourcePreview').innerHTML='<span>＋</span>';$('videoPreview').innerHTML='<span>＋</span>';$('sourceName').textContent='اضغط لاختيار صورة';$('videoName').textContent='اضغط لاختيار فيديو';$('videoMeta').textContent='حد أقصى 30 ثانية';$('fileValidation').textContent='لم يتم اختيار الملفات بعد.';$('timeline').value='0';$('timeline').disabled=true;$('playBtn').disabled=$('pauseBtn').disabled=true;$('playBtn').textContent='▶ تشغيل';$('emptyState').hidden=false;canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);$('engineStatus').textContent='لم يتم التحميل';$('engineDetail').textContent='MediaPipe Face Landmarker';setHint('ارفع ملفي المشروع لإعادة البدء.');setStatus('جاهز للفحص');setProgress(0,'جاهز للمعاينة');$('analyzeBtn').textContent='✦ تحليل الوجه وبدء المعاينة';validateReady();updateCapabilityStatus();
}

async function registerServiceWorker(){if(!('serviceWorker'in navigator))return;try{await navigator.serviceWorker.register('./sw.js');}catch(err){console.warn('Service worker registration failed:',err);}}

loadFileInputs();bindEvents();updateCapabilityStatus();registerServiceWorker();setStatus('جاهز للفحص');
