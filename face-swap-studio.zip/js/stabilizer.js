/** One Euro filter for jitter reduction with low latency on fast motion. */
export class LowPassFilter {
  constructor(alpha = 1) { this.alpha = alpha; this.initialized = false; this.value = 0; }
  filter(value, alpha) {
    if (!this.initialized) { this.value = value; this.initialized = true; return value; }
    this.value = alpha * value + (1 - alpha) * this.value;
    return this.value;
  }
  reset() { this.initialized = false; this.value = 0; }
}
export class OneEuroFilter {
  constructor({ minCutoff = 1.2, beta = 0.02, dCutoff = 1 } = {}) {
    this.minCutoff = minCutoff; this.beta = beta; this.dCutoff = dCutoff;
    this.valueFilter = new LowPassFilter(); this.derivativeFilter = new LowPassFilter();
    this.lastTime = null; this.lastRaw = null;
  }
  alpha(cutoff, dt) { const tau = 1 / (2 * Math.PI * cutoff); return 1 / (1 + tau / Math.max(dt, 1e-4)); }
  filter(value, timeSeconds) {
    if (this.lastTime === null) { this.lastTime = timeSeconds; this.lastRaw = value; return this.valueFilter.filter(value, 1); }
    const dt = Math.max(1 / 120, Math.min(.2, timeSeconds - this.lastTime));
    const derivative = (value - this.lastRaw) / dt;
    const ed = this.derivativeFilter.filter(derivative, this.alpha(this.dCutoff, dt));
    const cutoff = this.minCutoff + this.beta * Math.abs(ed);
    const filtered = this.valueFilter.filter(value, this.alpha(cutoff, dt));
    this.lastTime = timeSeconds; this.lastRaw = value; return filtered;
  }
  reset() { this.valueFilter.reset(); this.derivativeFilter.reset(); this.lastTime = null; this.lastRaw = null; }
}
export class LandmarkStabilizer {
  constructor() { this.filters = []; this.lastLandmarks = null; this.lostFrames = 0; }
  process(landmarks, timeSeconds, strength = .55) {
    if (!landmarks?.length) return this.hold();
    if (this.filters.length !== landmarks.length) this.filters = landmarks.map(() => ({ x: new OneEuroFilter(), y: new OneEuroFilter(), z: new OneEuroFilter() }));
    const minCutoff = 1.5 - Math.min(.85, strength * .9);
    const beta = .018 + strength * .075;
    const result = landmarks.map((p, i) => {
      const f = this.filters[i];
      for (const axis of ['x', 'y', 'z']) { f[axis].minCutoff = minCutoff; f[axis].beta = beta; }
      return { x: f.x.filter(p.x, timeSeconds), y: f.y.filter(p.y, timeSeconds), z: f.z.filter(p.z ?? 0, timeSeconds) };
    });
    this.lastLandmarks = result; this.lostFrames = 0; return result;
  }
  hold(maxFrames = 5) { this.lostFrames++; return this.lastLandmarks && this.lostFrames <= maxFrames ? this.lastLandmarks : null; }
  reset() { this.filters = []; this.lastLandmarks = null; this.lostFrames = 0; }
}
