const CACHE_NAME = 'face-swap-studio-v1';
const CORE_FILES = [
  './', './index.html', './manifest.webmanifest', './css/styles.css',
  './js/app.js', './js/face-engine.js', './js/face-alignment.js',
  './js/face-mesh.js', './js/stabilizer.js', './js/renderer.js',
  './js/color-matcher.js', './js/video-export.js', './js/ui-controls.js',
  './vendor/delaunator/delaunator.js'
];
const LARGE_ASSETS = [
  './vendor/mediapipe/vision_bundle.mjs',
  './vendor/mediapipe/wasm/vision_wasm_internal.js',
  './vendor/mediapipe/wasm/vision_wasm_internal.wasm',
  './vendor/mediapipe/wasm/vision_wasm_nosimd_internal.js',
  './vendor/mediapipe/wasm/vision_wasm_nosimd_internal.wasm',
  './models/face_landmarker.task'
];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(CORE_FILES);
    // Optional large runtime files are cached individually so an absent model
    // cannot prevent the UI shell from installing and displaying diagnostics.
    for (const path of LARGE_ASSETS) {
      try { const response = await fetch(path); if (response.ok) await cache.put(path, response); }
      catch (error) { console.warn('Offline asset not cached:', path, error); }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('face-swap-studio-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && (request.destination !== 'document' || response.type === 'basic')) {
        try { await cache.put(request, response.clone()); } catch (cacheError) { console.warn('Could not cache response:', cacheError); }
      }
      return response;
    } catch (error) {
      if (request.mode === 'navigate') return (await cache.match('./index.html')) || Response.error();
      return Response.error();
    }
  })());
});
