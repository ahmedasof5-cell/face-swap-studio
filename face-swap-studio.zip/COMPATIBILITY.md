# Compatibility and QA report

**Report date:** 2026-10-31

## What was actually tested

| Area | Result | Method |
|---|---|---|
| JavaScript syntax | PASS | `npm run check` |
| Core math / triangulation | PASS — 5/5 | `npm test` using Node 22 |
| Relative module paths | PASS | Static scan of local JS imports |
| HTML ID wiring | PASS | Static duplicate-ID and app-reference scan |
| Asset bootstrap script | PASS | `bash -n scripts/fetch-assets.sh` |
| HTTP server response | PASS | Python static server returned `index.html` with HTTP 200 |
| Browser DOM smoke test | NOT VERIFIED | Headless Chromium was present but stalled before DOM output; no browser pass claimed |
| MediaPipe inference | NOT TESTED | Official bundle/model could not be downloaded in this environment. |
| Video face-swap render | NOT TESTED | Requires MediaPipe runtime/model and test media in a browser |
| MediaRecorder / audio mux | NOT TESTED | Runtime-gated code; no browser export session was available |
| Offline Service Worker | NOT TESTED END-TO-END | Requires successful online asset population in a real browser |
| iPhone 12 Safari | NOT TESTED | No physical iPhone was attached |

## Browser capability expectations

| Capability | App behavior |
|---|---|
| ES modules | Required; serve via HTTPS or localhost |
| MediaPipe WASM | Loaded from local `vendor/mediapipe/wasm/` after bootstrap |
| Face model | Loaded from local `models/face_landmarker.task` |
| GPU | Attempted first; CPU delegate fallback is coded |
| Canvas 2D | Required for the current renderer |
| `requestVideoFrameCallback` | Used when available; animation-frame fallback is provided |
| `canvas.captureStream` | Required to expose video export; export is disabled/rejected when unavailable |
| MediaRecorder | Runtime MIME detection; MP4 preferred only when reported supported, otherwise WebM |
| Web Audio | Optional; source audio track included when browser APIs permit it |
| Web Share files | Optional; download remains the fallback |
| Service Worker | Requires HTTPS or localhost; caches assets after first online visit |

## iPhone-specific caveats

- No physical iPhone validation was performed. Performance, RAM headroom, heat, codec decode and output format must be checked on the actual iPhone/Safari version.
- A 30-second video can still consume significant memory. 480p is the safer first test on older mobile hardware.
- Synchronous `detectForVideo` inference blocks the main thread. Preview inference is throttled; export tries each decoded frame and may take longer than real time.
- 30 FPS is a capture target, not a guaranteed inference/render rate.
- Camera Roll saving is not claimed. Use the share sheet or download flow if Safari supports it.
